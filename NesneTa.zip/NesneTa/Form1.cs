﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using AForge;
using AForge.Imaging.Filters;
using AForge.Imaging;
using AForge.Video;
using AForge.Video.DirectShow;
using System.Drawing.Imaging;
using Point = System.Drawing.Point;
using System.IO.Ports;




namespace NesneTa
{
    public partial class Form1 : Form
    {
        Bitmap kaynak, islem;
        int oncekiDeger = -1;
        public Form1()
        {
            InitializeComponent();
            serialPort1.PortName = "COM5";
            serialPort1.BaudRate = 9600;
            serialPort1.Open();
        }

        private FilterInfoCollection VideoCapTureDevices;
        private VideoCaptureDevice Finalvideo;

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = SerialPort.GetPortNames();
            toolStrip1.Text = "";
            button4.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;

            int portSayisi = 0;
            portSayisi = comboBox2.Items.Count;
            if (portSayisi < 1)
            {
                button3.Enabled = false;
                toolStrip1.Text = "Aygıt bulunamadı. Bağlantıyı kontrol et";
            }

            VideoCapTureDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo VideoCaptureDevice in VideoCapTureDevices)
            {

                comboBox2.Items.Add(VideoCaptureDevice.Name);

            }

            comboBox2.SelectedIndex = 0;
            Finalvideo = new VideoCaptureDevice();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (serialPort1.IsOpen == true)
            {
                toolStrip1.Text = serialPort1.PortName + " portuna bağlandı.";
                button4.Enabled = true;
                button1.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = false;

            }
            else
            {
                toolStrip1.Text = "Porta bağlamadı. Kontrol et";
            }

        }
        private void Finalvideo_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            Bitmap image = (Bitmap)eventArgs.Frame.Clone();          
            Bitmap image1 = (Bitmap)eventArgs.Frame.Clone();
            Console.WriteLine(image.Size);
            pictureBox1.Image = image;


            
            ColorFiltering filter = new ColorFiltering();
            filter.Red = new IntRange(100, 255);
            filter.Blue = new IntRange(0, 75);
            filter.Green = new IntRange(0, 75);
            filter.ApplyInPlace(image1);
            nesnebul(image1);
           
        }
        private void nesnebul(Bitmap image)

        {
            BlobCounter bc = new BlobCounter();

            bc.MinHeight = 20;
            bc.MinWidth = 20;
            bc.FilterBlobs = true;
            bc.ObjectsOrder = ObjectsOrder.Size;
            BitmapData objectData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.ReadOnly, image.PixelFormat);
            Grayscale grayscaleFilter = new Grayscale(0.2125, 0.7154, 0.0721);
            UnmanagedImage grayImage = grayscaleFilter.Apply(new UnmanagedImage(objectData));
            image.UnlockBits(objectData);
            bc.ProcessImage(image);
            Rectangle[] rects = bc.GetObjectsRectangles();
            Blob[] blobs = bc.GetObjectsInformation();
           
            foreach (Rectangle rect in rects)
            {
                if (rects.Length > 0)
                {
                    Rectangle objectRect = rects[0];
                    Graphics g = pictureBox1.CreateGraphics();
                    using (Pen pen = new Pen(Color.FromArgb(255, 5, 10), 5))
                    {
                        g.DrawRectangle(pen, objectRect);
                    }
                    int objectX = objectRect.X + (objectRect.Width / 2);
                    int objectY = objectRect.Y + (objectRect.Height / 2);
                    g.Dispose();
                    {
                        this.Invoke((MethodInvoker)delegate
                        {
                            richTextBox1.Text = objectRect.Location.ToString() + "\n" + richTextBox1.Text + "\n";
                            if (objectX < 213 && objectY < 160)
                            {
                                textBox1.Text = "1. LED";
                                SeriYaz("1");
                            }
                            else if ((objectX > 213 && objectX < 426) && (objectY < 160))
                            {
                                textBox1.Text = "2. LED";
                                SeriYaz("2");
                            }
                            else if ((objectX > 426 ) && (objectY < 160))
                            {
                                textBox1.Text = "3. LED";
                                SeriYaz("3");
                            }
                            else if ((objectX < 213) && (objectY > 160 && objectY < 320))
                            {
                                textBox1.Text = "4. LED";
                                SeriYaz("4");
                            }
                            else if ((objectX > 213 && objectX < 426) && (objectY > 160 && objectY < 320))
                            {
                                textBox1.Text = "5. LED";
                                SeriYaz("5");
                            }
                            else if ((objectX > 416) && (objectY > 160 && objectY < 320))
                            {
                                textBox1.Text = "6. LED";
                                SeriYaz("6");
                            }
                            else if ((objectX < 213) && (objectY > 320))
                            {
                                textBox1.Text = "7. LED";
                                SeriYaz("7");
                            }
                            else if ((objectX > 213 && objectX < 426) && (objectY > 320))
                            {
                                textBox1.Text = "8. LED";
                                SeriYaz("8");
                            }
                            else if ((objectX > 416) && (objectY > 320))
                            {
                                textBox1.Text = "9. LED";
                                SeriYaz("9");
                            }




                            
                            islem = image;
                            Bitmap cizim = new Bitmap(islem.Width, islem.Height);
                            g = Graphics.FromImage(cizim);
                            g.DrawImage(islem, 0, 0);
                            Pen cerceve = new Pen(Color.Red, 2);
                            foreach (Rectangle recs in rects)
                            {
                                listBox1.Items.Add(rect.Location + " " + rect.Size);
                                g.DrawRectangle(cerceve, rect);
                            }
                            g.Dispose();
                            pictureBox2.Image = cizim;



                        });

                        
                      
                    }
                }
            }
        }
        public void SeriYaz(string mesaj)
        {
            
            Console.WriteLine(mesaj);
            if (!serialPort1.IsOpen)
            {
                serialPort1.Open();
            }
            serialPort1.Write(mesaj);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            serialPort1.Write("1");
            toolStrip1.Text = "Led Yandı";

            if (Finalvideo.IsRunning)
            {
                Finalvideo.Stop();

            }
            Application.Exit();
        }

        private Point[] ToPointsArray(List<IntPoint> points)
        {
            Point[] array = new Point[points.Count];

            for (int i = 0, n = points.Count; i < n; i++)
            {
                array[i] = new Point(points[i].X, points[i].Y);
            }

            return array;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            serialPort1.Write("0");
            toolStrip1.Text = "Led Kapandı";


        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            toolStrip1.Text = "Bağlantı Kesildi";
            button4.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = true;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Finalvideo = new VideoCaptureDevice(VideoCapTureDevices[comboBox2.SelectedIndex].MonikerString);
            Finalvideo.NewFrame += new NewFrameEventHandler(Finalvideo_NewFrame);
            Finalvideo.DesiredFrameRate = 20;//saniyede kaç görüntü alınsın FPS
            Finalvideo.DesiredFrameSize = new Size(640, 480);//görüntü boyutları
            Finalvideo.Start();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
            if (serialPort1.IsOpen == true)
            {
                toolStrip1.Text = serialPort1.PortName + " portuna bağlandı.";
                button4.Enabled = true;
                button1.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = false;

            }
            else
            {
                toolStrip1.Text = "Porta bağlamadı. Kontrol et!!";
            }
        }

    }
}