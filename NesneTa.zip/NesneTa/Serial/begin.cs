﻿namespace Serial
{
    internal class begin
    {
    }
}